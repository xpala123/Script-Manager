-- Passagier-Einkommen mit Entfernungsabschlag.
-- Kurze Strecken bleiben wie im Basisspiel, lange Strecken bringen pro
-- zurueckgelegtem Meter immer weniger ein (logistischer Abfall).
--
-- WICHTIG: Diese Datei gibt die Tabelle direkt per "return" zurueck, genau wie
-- mod.script.tl. Es gibt bewusst KEIN "function data()": das wuerde eine
-- globale Funktion anlegen, und Transport Fever 3 unterstuetzt keine globalen
-- Variablen.
--
-- Stellschrauben:
--   decayStart    Entfernung (interne Einheit, ungefaehr Meter), bei der der
--                 Abschlag zur Haelfte erreicht ist
--   decayWidth    je kleiner, desto abrupter der Abfall
--   minFactor     Untergrenze: so viel vom Basis-Satz bleibt auf sehr langen
--                 Strecken uebrig (0.35 = 35 %)

local decayStart = 4000.
local decayWidth = 1500.
local minFactor = 0.35

local logCount = 0
local maxLogCount = 20

local rawFactor = function(distance)
	return minFactor + (1. - minFactor) / (1. + math.exp((distance - decayStart) / decayWidth))
end

-- normiert, damit sehr kurze Strecken genau Faktor 1.0 behalten
local factorAtZero = rawFactor(0.)

local distanceFactor = function(distance)
	return math.min(1., rawFactor(distance) / factorAtZero)
end

-- Luftlinie plus 8-fache Hoehendifferenz bergauf (wie bei Fracht im Basisspiel)
local calcTravelDistance = function(posDifference)
	local dx, dy, dz = posDifference[1], posDifference[2], posDifference[3]
	local travelDistance = math.sqrt(dx * dx + dy * dy + dz * dz)
	return travelDistance + 8. * math.max(dz, 0.)
end

return {
	calcPassengerIncomeFn = function(captureParams, incomeFactor, posDifference, vehiclePriceFactor)
		local travelDistance = calcTravelDistance(posDifference)
		local factor = distanceFactor(travelDistance)
		local difficulty = (captureParams and captureParams.difficultyFactor) or 1.
		local income = incomeFactor * difficulty * travelDistance * (0.5 + (vehiclePriceFactor or 0.5)) * factor
		if logCount < maxLogCount then
			logCount = logCount + 1
			print("[economy_balance] DIST passenger internalDistance=" .. tostring(travelDistance)
				.. " distanceFactor=" .. tostring(factor)
				.. " income=" .. tostring(income))
		end
		return income
	end,
}
